(function(){Meteor.startup(function () {
  if (Meteor.users.find().count() === 0) {
    var usuario_id = Accounts.createUser({
      username: 'admin',
      password: 'inter123',
      profile: {
        nombre: 'Administrador',
        departamento_id: 'Recursos humanos'
      }

    });
    Roles.addUsersToRoles(usuario_id, "admin");
  }
});

/*  Meteor.methods({

    changePassword:function(userId, newPassword){
      var usuario = Meteor.users.findOne({'username' : userId});
      Accounts.setPassword(usuario._id, newPassword);      
    }
 
});*/
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9zZXJ2ZXIvaW5pdGlhbGl6ZXJzL3VzZXJzLmluaXRpYWxpemVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sQ0FBQyxPQUFPLENBQUMsWUFBWTtBQUN6QixNQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxFQUFFO0FBQ3JDLFFBQUksVUFBVSxHQUFFLFFBQVEsQ0FBQyxVQUFVLENBQUM7QUFDbEMsY0FBUSxFQUFFLE9BQU87QUFDakIsY0FBUSxFQUFFLFVBQVU7QUFDcEIsYUFBTyxFQUFFO0FBQ1IsY0FBTSxFQUFFLGVBQWU7QUFDdEIsdUJBQWUsRUFBRSxrQkFBa0I7T0FDcEM7O0tBRUYsQ0FBQyxDQUFDO0FBQ0wsU0FBSyxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7R0FDMUM7Q0FDRixDQUFDLENBQUMiLCJmaWxlIjoiL3NlcnZlci9pbml0aWFsaXplcnMvdXNlcnMuaW5pdGlhbGl6ZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJNZXRlb3Iuc3RhcnR1cChmdW5jdGlvbiAoKSB7XG4gIGlmIChNZXRlb3IudXNlcnMuZmluZCgpLmNvdW50KCkgPT09IDApIHtcbiAgICB2YXIgdXN1YXJpb19pZD0gQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgICB1c2VybmFtZTogJ2FkbWluJyxcbiAgICAgIHBhc3N3b3JkOiAnaW50ZXIxMjMnLFxuICAgICAgcHJvZmlsZToge1xuXHQgICAgICBub21icmU6ICdBZG1pbmlzdHJhZG9yJyxcbiAgICAgICAgZGVwYXJ0YW1lbnRvX2lkOiAnUmVjdXJzb3MgaHVtYW5vcydcbiAgICAgIH1cblxuICAgIH0pO1xuXHRcdFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyh1c3VhcmlvX2lkLCBcImFkbWluXCIpO1xuICB9XG59KTtcblxuXG4vKiAgTWV0ZW9yLm1ldGhvZHMoe1xuXG4gICAgY2hhbmdlUGFzc3dvcmQ6ZnVuY3Rpb24odXNlcklkLCBuZXdQYXNzd29yZCl7XG4gICAgICB2YXIgdXN1YXJpbyA9IE1ldGVvci51c2Vycy5maW5kT25lKHsndXNlcm5hbWUnIDogdXNlcklkfSk7XG4gICAgICBBY2NvdW50cy5zZXRQYXNzd29yZCh1c3VhcmlvLl9pZCwgbmV3UGFzc3dvcmQpOyAgICAgIFxuICAgIH1cbiBcbn0pOyovIl19
}).call(this);
