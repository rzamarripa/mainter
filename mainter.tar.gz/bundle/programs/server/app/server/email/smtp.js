(function(){Meteor.startup(function () {

  process.env.MAIL_URL = 'smtp://interceramic:interceramic123@smtp.sendgrid.net:587';
  //process.env.MAIL_URL = 'smtp://' + encodeURIComponent(smtp.username) + ':' + encodeURIComponent(smtp.password) + '@' + encodeURIComponent(smtp.server) + ':' + smtp.port;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9zZXJ2ZXIvZW1haWwvc210cC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLENBQUMsT0FBTyxDQUFDLFlBQVk7O0FBRXpCLFNBQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxHQUFHLDJEQUEyRCxDQUFDOztDQUVwRixDQUFDLENBQUMiLCJmaWxlIjoiL3NlcnZlci9lbWFpbC9zbXRwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiTWV0ZW9yLnN0YXJ0dXAoZnVuY3Rpb24gKCkge1xuICBcbiAgcHJvY2Vzcy5lbnYuTUFJTF9VUkwgPSAnc210cDovL2ludGVyY2VyYW1pYzppbnRlcmNlcmFtaWMxMjNAc210cC5zZW5kZ3JpZC5uZXQ6NTg3JztcbiAgLy9wcm9jZXNzLmVudi5NQUlMX1VSTCA9ICdzbXRwOi8vJyArIGVuY29kZVVSSUNvbXBvbmVudChzbXRwLnVzZXJuYW1lKSArICc6JyArIGVuY29kZVVSSUNvbXBvbmVudChzbXRwLnBhc3N3b3JkKSArICdAJyArIGVuY29kZVVSSUNvbXBvbmVudChzbXRwLnNlcnZlcikgKyAnOicgKyBzbXRwLnBvcnQ7XG59KTsiXX0=
}).call(this);
