(function(){Meteor.methods({
  sendEmail: function sendEmail(to, from, subject, html) {

    // Let other method calls from the same client start running,
    // without waiting for the email sending to complete.
    this.unblock();

    Email.send({
      to: to,
      from: from,
      subject: subject,
      html: html
    });
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9zZXJ2ZXIvZW1haWwvZW1haWwuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNiLFdBQVMsRUFBRSxtQkFBVSxFQUFFLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUU7Ozs7QUFJNUMsUUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDOztBQUVmLFNBQUssQ0FBQyxJQUFJLENBQUM7QUFDVCxRQUFFLEVBQUUsRUFBRTtBQUNOLFVBQUksRUFBRSxJQUFJO0FBQ1YsYUFBTyxFQUFFLE9BQU87QUFDaEIsVUFBSSxFQUFFLElBQUk7S0FDWCxDQUFDLENBQUM7R0FDSjtDQUNGLENBQUMsQ0FBQyIsImZpbGUiOiIvc2VydmVyL2VtYWlsL2VtYWlsLmpzIiwic291cmNlc0NvbnRlbnQiOlsiTWV0ZW9yLm1ldGhvZHMoe1xuICBzZW5kRW1haWw6IGZ1bmN0aW9uICh0bywgZnJvbSwgc3ViamVjdCwgaHRtbCkge1xuXG4gICAgLy8gTGV0IG90aGVyIG1ldGhvZCBjYWxscyBmcm9tIHRoZSBzYW1lIGNsaWVudCBzdGFydCBydW5uaW5nLFxuICAgIC8vIHdpdGhvdXQgd2FpdGluZyBmb3IgdGhlIGVtYWlsIHNlbmRpbmcgdG8gY29tcGxldGUuXG4gICAgdGhpcy51bmJsb2NrKCk7XG5cbiAgICBFbWFpbC5zZW5kKHtcbiAgICAgIHRvOiB0byxcbiAgICAgIGZyb206IGZyb20sXG4gICAgICBzdWJqZWN0OiBzdWJqZWN0LFxuICAgICAgaHRtbDogaHRtbFxuICAgIH0pO1xuICB9XG59KTsiXX0=
}).call(this);
