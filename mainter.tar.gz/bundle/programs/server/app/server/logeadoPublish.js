(function(){Meteor.publish("logeado", function () {

    //returns undefined if not logged in so check if logged in first
    if (this.userId) {
        var user = Meteor.users.findOne(this.userId);
        //var user is the same info as would be given in Meteor.user();
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9zZXJ2ZXIvbG9nZWFkb1B1Ymxpc2guanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsWUFBVTs7O0FBR2hDLFFBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRTtBQUNaLFlBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzs7S0FFaEQ7Q0FDSixDQUFDLENBQUMiLCJmaWxlIjoiL3NlcnZlci9sb2dlYWRvUHVibGlzaC5qcyIsInNvdXJjZXNDb250ZW50IjpbIk1ldGVvci5wdWJsaXNoKFwibG9nZWFkb1wiLCBmdW5jdGlvbigpe1xuXG4gICAgLy9yZXR1cm5zIHVuZGVmaW5lZCBpZiBub3QgbG9nZ2VkIGluIHNvIGNoZWNrIGlmIGxvZ2dlZCBpbiBmaXJzdFxuICAgIGlmKHRoaXMudXNlcklkKSB7XG4gICAgICAgIHZhciB1c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUodGhpcy51c2VySWQpO1xuICAgICAgICAvL3ZhciB1c2VyIGlzIHRoZSBzYW1lIGluZm8gYXMgd291bGQgYmUgZ2l2ZW4gaW4gTWV0ZW9yLnVzZXIoKTtcbiAgICB9XG59KTtcbiJdfQ==
}).call(this);
