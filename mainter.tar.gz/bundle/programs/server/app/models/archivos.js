(function(){Archivos = new Mongo.Collection("archivos");
Archivos.allow({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9tb2RlbHMvYXJjaGl2b3MuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsUUFBUSxHQUFlLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN4RCxRQUFRLENBQUMsS0FBSyxDQUFDO0FBQ2IsUUFBTSxFQUFFLGtCQUFZO0FBQUUsV0FBTyxJQUFJLENBQUM7R0FBRTtBQUNwQyxRQUFNLEVBQUUsa0JBQVk7QUFBRSxXQUFPLElBQUksQ0FBQztHQUFFO0FBQ3BDLFFBQU0sRUFBRSxrQkFBWTtBQUFFLFdBQU8sSUFBSSxDQUFDO0dBQUU7Q0FDckMsQ0FBQyxDQUFDIiwiZmlsZSI6Ii9tb2RlbHMvYXJjaGl2b3MuanMiLCJzb3VyY2VzQ29udGVudCI6WyJBcmNoaXZvcyAgICAgICAgICAgICA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiYXJjaGl2b3NcIik7XG5BcmNoaXZvcy5hbGxvdyh7XG4gIGluc2VydDogZnVuY3Rpb24gKCkgeyByZXR1cm4gdHJ1ZTsgfSxcbiAgdXBkYXRlOiBmdW5jdGlvbiAoKSB7IHJldHVybiB0cnVlOyB9LFxuICByZW1vdmU6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRydWU7IH1cbn0pOyJdfQ==
}).call(this);
