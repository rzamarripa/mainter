(function(){Home = new Mongo.Collection("home");
Home.allow({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9tb2RlbHMvaG9tZS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxJQUFJLEdBQVMsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDVCxRQUFNLEVBQUUsa0JBQVk7QUFBRSxXQUFPLElBQUksQ0FBQztHQUFFO0FBQ3BDLFFBQU0sRUFBRSxrQkFBWTtBQUFFLFdBQU8sSUFBSSxDQUFDO0dBQUU7QUFDcEMsUUFBTSxFQUFFLGtCQUFZO0FBQUUsV0FBTyxJQUFJLENBQUM7R0FBRTtDQUNyQyxDQUFDLENBQUMiLCJmaWxlIjoiL21vZGVscy9ob21lLmpzIiwic291cmNlc0NvbnRlbnQiOlsiSG9tZSBcdFx0XHRcdFx0XHQ9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiaG9tZVwiKTtcbkhvbWUuYWxsb3coe1xuICBpbnNlcnQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRydWU7IH0sXG4gIHVwZGF0ZTogZnVuY3Rpb24gKCkgeyByZXR1cm4gdHJ1ZTsgfSxcbiAgcmVtb3ZlOiBmdW5jdGlvbiAoKSB7IHJldHVybiB0cnVlOyB9XG59KTsiXX0=
}).call(this);
