(function(){Mercas = new Mongo.Collection("mercas");
Mercas.allow({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9tb2RlbHMvbWVyY2FzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sR0FBUyxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDOUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNYLFFBQU0sRUFBRSxrQkFBWTtBQUFFLFdBQU8sSUFBSSxDQUFDO0dBQUU7QUFDcEMsUUFBTSxFQUFFLGtCQUFZO0FBQUUsV0FBTyxJQUFJLENBQUM7R0FBRTtBQUNwQyxRQUFNLEVBQUUsa0JBQVk7QUFBRSxXQUFPLElBQUksQ0FBQztHQUFFO0NBQ3JDLENBQUMsQ0FBQyIsImZpbGUiOiIvbW9kZWxzL21lcmNhcy5qcyIsInNvdXJjZXNDb250ZW50IjpbIk1lcmNhcyBcdFx0XHRcdFx0XHQ9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwibWVyY2FzXCIpO1xuTWVyY2FzLmFsbG93KHtcbiAgaW5zZXJ0OiBmdW5jdGlvbiAoKSB7IHJldHVybiB0cnVlOyB9LFxuICB1cGRhdGU6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRydWU7IH0sXG4gIHJlbW92ZTogZnVuY3Rpb24gKCkgeyByZXR1cm4gdHJ1ZTsgfVxufSk7Il19
}).call(this);
