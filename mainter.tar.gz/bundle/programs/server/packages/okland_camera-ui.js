(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MeteorCamera = Package['mdg:camera'].MeteorCamera;

/* Package-scope variables */
var MeteorCameraUI;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/okland_camera-ui/packages/okland_camera-ui.js                 //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/okland:camera-ui/camera-ui.js                            //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
MeteorCameraUI = {};                                                 // 1
                                                                     // 2
                                                                     // 3
///////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['okland:camera-ui'] = {}, {
  MeteorCameraUI: MeteorCameraUI
});

})();

//# sourceMappingURL=okland_camera-ui.js.map
